#!/usr/bin/env python
# -*- coding: utf-8 -*-
# author： juzipi
# datetime： 2021/12/30
# software： PyCharm
# description：
# contact： 1129501586@qq.com
# blog: https://piqiandong.blog.csdn.net

from ChineseTextEDA.eda import SimpleEDAEnhance

sed = SimpleEDAEnhance()
sed.simple_eda_enhance()
